# The word variable in programming describes a place to store information such as numbers, text, lists of numbers and text, and so on. Another way of looking at a variable is that it’s like a label for something.

# For example, to create a variable named fred, we use an equal sign (=) and then tell Python what information the variable should be the label for. Here, we create the variable a and tell Python that it labels the name "hello world" or anything else (note that this doesn’t mean that another variable can’t have the same value)

# Syntax to make variable

# First write name of the variable

# There is many rules of naming the variable
# 1. Variables don't starts with numbers but you can use numbers between or end in a variable
# 2. Variables don't contain a special characters
# 3. Variables don't contain spaces (You can use underscore sign (-) instead of spaces)

# Label the data that you want to store in that variable

var = "hello world"
var2 = 2323

print(var)
print(var2)

# rewriting variable
var = 1290
print(var)

total_amounts = 1234
print(total_amounts)