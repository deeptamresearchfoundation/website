# a = '''This is a string
# this is running in vs code
# this is python programming'''
# print(a)
# print(type(a))

# a = 'I said,"this is ram\'s book"'
# b = "Yes"
# print(a, end=" ")
# print(b)
