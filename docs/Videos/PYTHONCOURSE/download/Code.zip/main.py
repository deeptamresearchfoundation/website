print("Hello world")

print("this is my first programm in python")