a = "this is the tutorial of strings"
print(a)

print(len(a)) # len function is used to find the lenght of the strings alongwith spaces
print(a[1]) # square brackets is used to find the word in the 1 number (index is start with 0)


# calculation of strings
print(a * 100) # prints a variable 100 times

# when you run this code you will see that a varible print the value one line aside
# If you want to print variable a in new line You can do

a = "this is the tutorial of strings\n" # \n is used to make a new line

# concatanating of strings
# If you want to concatanate the strings you can use '+' sign as follow

a = "hello"
b = "world" 

# if you want to concatanate a and b variable
print(a + b) # concatanate variable a and b

# embedding strings

a = "I have Scored"
b = "1000 points"

print("I have Scored %s" % b) # %s is use to embed strings

# other calculation like subtraction, division, etc..