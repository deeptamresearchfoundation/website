# datatypes in python

# 1. numeric
# 2. None
# 3. sets
# 4. sequence type
# 5. boolean
# 6. maps or dictionary

# numeric types
# 1. int or integer
# 2. float or decimal value
# 3. complex 

# sequence type
# 1. strings
# 2. lists
# 3. tuples

# int or integer value
# a = 89
# print(a)
# print(a + 89)

# float or decimal value
# num1 = 2.1
# print(type(num1))
# print(num1 // 10)

# complex type



num1 = 3 + 4j
num2 = 6 + 8j

print(num1 / num2)