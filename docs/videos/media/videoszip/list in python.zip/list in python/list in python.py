a = ["C", "C++", "Python", "Java"]
print(type(a))
print(a)

print(a[1]) # print the index no. item of the list
# print(a[4])

a[1] = "Java"
a[3] = "C++"
# print(a)
a[1] = "C++"
a[3] = "Java"
print(a)

a.append("Swift")
# print(a)

a[4] = "Java"
a[3] = "Swift"
# print(a)

del a[3]
print(a)

list1 = ["I", "have", "scored"]
list2 = [10000, "points"]

list1 = [10000, "points"]

print(list1 + list2)
print(list2 * 12)
# print(list2 - 20) When you run this line you will get an error because we can't take subtraction and division of List</textarea>
