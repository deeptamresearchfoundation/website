a = (89, "tuple", 69)
print(a)
print(type(a))
print(a[0])
